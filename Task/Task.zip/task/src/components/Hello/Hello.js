import React from "react";
import "./hello.css";
const Hello=()=>{
    return(
        <>
            <div className="center">
                <h1>Hello <span>User....</span></h1>
            </div>
            
        </>
    );
}
export default Hello;